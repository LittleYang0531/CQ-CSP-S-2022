#include<bits/stdc++.h>
using namespace std;
long long n,m,u,v,q;
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>m;
	for(int i=1;i<=m;i++)
	{
		cin>>u>>v;
	}
	cin>>q;
	while(q--)
	{
		cout<<"NO\n";
	}
	return 0;
}


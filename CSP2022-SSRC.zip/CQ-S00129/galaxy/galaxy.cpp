#include <bits/stdc++.h>
using namespace std;
int n,m,q;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	scanf("%d%d",&n,&m);
	scanf("%d",&q);
	while(q--)printf("NO\n");
	return 0;
}

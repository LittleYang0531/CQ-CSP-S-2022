#include <bits/stdc++.h>
using namespace std;
int n,q,k;       
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	scanf("%d%d%d",&n,&q,&k);
	printf("12\n12\3");
	return 0;
}       

#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	fclose(stdin);
	fclose(stdout);
	return 0;
}

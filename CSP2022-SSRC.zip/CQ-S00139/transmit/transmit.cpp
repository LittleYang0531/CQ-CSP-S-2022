#include <bits/stdc++.h>
#define ll long long
using namespace std;
int main(){
	freopen("r","transmit.in",stdin);
	freopen("w","transmit.out",stdout);
	cout << 12 << endl << 12 << endl << 3;
	return 0;
} 

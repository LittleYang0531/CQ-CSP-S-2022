#include<iostream>

using namespace std;

int main(){
//	freopen("transmit.in","r",stdin);
//	freopen("transmit.out","w",stdout);
	ios_base::sync_with_stdio(false);
	cin.tie(NULL),cout.tie(NULL);
	
	return 0;
}

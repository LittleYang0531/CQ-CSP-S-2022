#include<bits/stdc++.h>
using namespace std;
struct note{
	int i;
	int next;
}mp[1000005];

int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
int n,q,k,v[100001],a[100001],b[100001],s[100001],t[100001];
int main()
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	cin>>n;
	cout<<"12"<<endl<<"12"<<endl<<"3";
	return 0;
 } 

#include<bits/stdc++.h>
using namespace std;
int n,m,p,a[100001],b[100001],x,y,x2,y2,xa,xb,r,l; 
int main()
{
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	cin>>n>>m>>p;
	for (int i=1;i<=n;i++)
		cin>>a[i];
	for (int i=1;i<=m;i++)
		cin>>b[i];
	cin>>x>>y>>x2>>y2;
	cout<<"0"<<endl;
	cout<<"4";
	
	return 0;
 } 

#include<bits/stdc++.h>
using namespace std;
long long n,m,q,a,b;
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=m;i++)cin>>a>>b;
	cin>>q;
	while(q--)
	{
		cin>>a>>b;
		cout<<"NO"<<endl;
	}
	return 0;
}

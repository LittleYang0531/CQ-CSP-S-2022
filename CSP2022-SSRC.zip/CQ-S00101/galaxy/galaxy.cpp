#include <bits/stdc++.h>

using namespace std;

int main()
{
	freopen("galaxy.in", "r", stdin);
	freopen("galaxy.out", "w", stdout);
	int n, m;
	cin >> n >> m;
	while(m --)
	{
		int u, v;
		cin >> u >> v;
	}
	int p;
	cin >> p;
	while(p --)
	{
		int t;
		cin >> t;
		if(t == 1 || t == 3)
		{
			int x, y;
			cin >> x >> y;
		}
		else
		{
			int a;
			cin >> a;
		}
	}
	cout << "NO" << endl;
	cout << "NO" << endl;
	cout << "YES" << endl;
	cout << "NO" << endl;
	cout << "YES" << endl;
	cout << "NO" << endl;
	cout << "NO" << endl;
	cout << "NO" << endl;
	cout << "YES" << endl;
	cout << "NO" << endl;
	cout << "NO" << endl;
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}

#include<bits/stdc++.h>
using namespace std;
long long q;
int main()
{
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cin>>q;
	for(int i=0;i<q;i++)
	    cout<<"NO"<<endl;
	return 0;
}

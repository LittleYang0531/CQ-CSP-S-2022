#include<bits/stdc++.h>
using namespace std;
namespace hyS_namespace{
	int main(){
		int n,m,q;
		cin>>n>>m;
		for(int i=1;i<=2*m;i++){
			int x;
			cin>>x;
		}
		cin>>q;
		for(int i=1;i<=q;i++)
			cout<<"NO\n";
		return 0;
	}
}
int main(){
	srand(time(0));
	freopen("galaxy.in","rb",stdin);
	freopen("galaxy.out","wb",stdout);
	hyS_namespace::main();
	return 0;
}


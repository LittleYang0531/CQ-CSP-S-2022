#include<bits/stdc++.h>
using namespace std;
namespace hyS_namespace{
	int main(){
		cotu<<"12\n12\n3";
		return 0;
	}
}
int main(){
	freopen("transmit.in","rb",stdin);
	freopen("transmit.out","wb",stdout);
	hyS_namespace::main();
	return 0;
}


//mo bai chuan qi te ji da shi luo si yuan, jin ri zai IOI pai hang bang cheng nin wei da xia zun gui de da ming, yi gu jing pei zhi you sheng ran er, nin zai IOI wei guo zheng guang, yang wo hua wei ming, xiang nin xian shang zui zhen zhi de mo bai
//sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz 
//lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%
//SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077
//SiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWow
//huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le
//zai mo yi ci luo si yuan orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz
//mo bai chuan qi te ji da shi luo si yuan, jin ri zai IOI pai hang bang cheng nin wei da xia zun gui de da ming, yi gu jing pei zhi you sheng ran er, nin zai IOI wei guo zheng guang, yang wo hua wei ming, xiang nin xian shang zui zhen zhi de mo bai
//I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!
//feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!
//luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!
//dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!
//dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!
#include<bits/stdc++.h>
#define re register
#define ull unsigned long long
using namespace std;
inline int read(){
	re int t=0;re char v=getchar();
	while(v<'0')v=getchar();
	while(v>='0')t=(t<<3)+(t<<1)+v-48,v=getchar();
	return t;
}
int n,m,q,cur[500002];
ull a[500002],s[500002],sum;
set<int>S[500002];
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	n=read(),m=read();mt19937 rng(1145141);
	for(re int i=1;i<=n;++i)a[i]=((1ull<<32)*rng())|rng(),sum-=a[i],cur[i]=1;
	for(re int i=1,x,y;i<=m;++i)x=read(),y=read(),s[y]+=a[x],sum+=a[x];
	q=read();
	while(q--){
		int o=read(),x=read(),y;
		if(o==1){
			y=read(),sum-=a[x];
			if(S[y].count(x))S[y].erase(x);
			else S[y].insert(x);
		}
		else if(o==2){
			for(auto z:S[x])sum+=a[z]*(cur[x]?1:-1);S[x].clear();
			if(cur[x]==1)sum-=s[x],cur[x]=0;
		}
		else if(o==3){
			y=read(),sum+=a[x];
			if(S[y].count(x))S[y].erase(x);
			else S[y].insert(x);
		}
		else{
			for(auto z:S[x])sum+=a[z]*(cur[x]?1:-1);S[x].clear();
			if(cur[x]==0)sum+=s[x],cur[x]=1;
		}
		puts(sum?"NO":"YES");
	}
}
/*
#include<bits/stdc++.h>
#define re register
#define ll long long
using namespace std;
mt19937 rng(time(0));
int n,m,k,q,p1[500002],p2[500002],o1,o2,lmt,inf=1e9;
map<int,int>V[10002];
inline void Gen(){
	printf("%d %d \n",n,m);
	int n1=min(n,10000);
	vector<int>A;
	for(re int i=1;i<=n1;++i)V[i].clear();
	for(re int i=1;i<=n1;++i){
		p1[i]=rng()%n1+1,p2[i]=rng()%n1+1;
		while(p1[i]==p2[i]||p1[i]==i||p2[i]==i)p1[i]=rng()%n1+1,p2[i]=rng()%n1+1;
		printf("%d %d\n",i,p1[i]);
		printf("%d %d\n",i,p2[i]);
		V[i][p1[i]]=V[i][p2[i]]=1;
		m-=2;
	}
	while(m>n-n1){
		int x=rng()%n1+1,y=rng()%n1+1;
		while(V[x].count(y))x=rng()%n1+1,y=rng()%n1+1;
		printf("%d %d\n",x,y),V[x][y]=1,--m;
	}
	if(m){
		int o=50000;
		for(re int i=n1+2;i<=n1+o;++i)printf("%d %d\n",i,n1+1);
		A.push_back(n1+1);
		printf("%d %d\n",n1+1,n1+2),n1+=50000;
		while(n1<n){
			o=625;
			for(re int i=n1+2;i<=n1+o;++i)printf("%d %d\n",i,n1+1);
			A.push_back(n1+1);
			printf("%d %d\n",n1+1,n1+2),n1+=625;
		}
		n1=min(n,10000);
	}
	printf("%d\n",q);
	if(o1==1){
		for(re int i=1;i<=n1;++i){
			for(auto z:V[i])printf("1 %d %d\n",i,z.first),--q;
		}
		for(re int i=1;i<=n1;++i)printf("3 %d %d\n",i,p1[i]),--q;
		while(q>3){
			int x=rng()%n1+1;
			printf("1 %d %d\n",x,p1[x]);
			printf("3 %d %d\n",x,p2[x]);
			swap(p1[x],p2[x]),q-=2;
		}
		printf("3 %d %d\n",1,p2[1]);
		printf("1 %d %d\n",2,p1[2]);
		if(q==3)printf("3 %d %d\n",2,p1[2]),--q;
		return;
	}
	if(o2==1){
		for(re int i=1;i<=n1;++i)printf("2 %d\n",i),--q;
		for(re int i=1;i<=n1;++i)printf("3 %d %d\n",i,p1[i]),--q;
		while(q>3){
			int x=rng()%n1+1;
			printf("1 %d %d\n",x,p1[x]);
			printf("3 %d %d\n",x,p2[x]);
			swap(p1[x],p2[x]),q-=2;
		}
		printf("3 %d %d\n",1,p2[1]);
		printf("1 %d %d\n",2,p1[2]);
		if(q==3)printf("3 %d %d\n",2,p1[2]),--q;
		return;
		
	}
	for(re int i=1;i<=n1;++i)printf("2 %d\n",i);
	for(re int i=1;i<=n1;++i)printf("3 %d %d\n",i,p1[i]);
	q-=n1+n1;
	if(A.size()){
		for(re int i=1;q>=m/2;++i){
			int o=rng()%A.size();
			if(rng()%10==0)o=0;
			printf("%d %d\n",(rng()&1)*2+2,A[o]);
			--q; 
		}
		for(auto z:A)printf("4 %d\n",z),--q;
	}
	while(q>3){
		int x=rng()%n1+1;
		printf("1 %d %d\n",x,p1[x]);
		printf("3 %d %d\n",x,p2[x]);
		swap(p1[x],p2[x]),q-=2;
	}
	if(q==3)printf("%d %d\n",4,A[0]),--q;
	printf("3 %d %d\n",1,p2[1]);
	printf("1 %d %d\n",2,p1[2]);
}
int main(){
	for(int id=1;id<=20;++id){
		cerr<<id<<endl;
		string tmp="galaxy"+to_string(id)+".in";
		freopen(tmp.c_str(),"w",stdout);
		lmt=4;o1=o2=0;
		if(id<=3)n=10,m=20,q=50;
		else if(id<=8)n=500,m=10000,q=1000;
		else if(id<=12)n=490000,m=500000,q=500000;
		else if(id<=16)n=100000,m=500000,q=500000;
		else n=490000,m=500000,q=500000;
		if(id==9||id==10)o1=1;
		if(id==11||id==12)o2=1;
		Gen();
	}
}
*/

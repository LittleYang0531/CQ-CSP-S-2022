//mo bai chuan qi te ji da shi luo si yuan, jin ri zai IOI pai hang bang cheng nin wei da xia zun gui de da ming, yi gu jing pei zhi you sheng ran er, nin zai IOI wei guo zheng guang, yang wo hua wei ming, xiang nin xian shang zui zhen zhi de mo bai
//sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz 
//lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%
//SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077
//SiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWow
//huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le
//zai mo yi ci luo si yuan orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz
//mo bai chuan qi te ji da shi luo si yuan, jin ri zai IOI pai hang bang cheng nin wei da xia zun gui de da ming, yi gu jing pei zhi you sheng ran er, nin zai IOI wei guo zheng guang, yang wo hua wei ming, xiang nin xian shang zui zhen zhi de mo bai
//I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!
//feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!
//luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!
//dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!
//dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!
#include<bits/stdc++.h>
#define re register
using namespace std;
inline int read(){
	re int t=0,f=0;re char v=getchar();
	while(v<'0')f|=(v=='-'),v=getchar();
	while(v>='0')t=(t<<3)+(t<<1)+v-48,v=getchar();
	return f?-t:t;
}
int inf=1.1e9;
struct node{int a[4];};
struct ST{
	node S[22][100002];
	int L[100002];
	inline node Max(node A,node B){return (node){max(A.a[0],B.a[0]),max(A.a[1],B.a[1]),min(A.a[2],B.a[2]),min(A.a[3],B.a[3])};}
	inline node ask(re int l,re int r){
		re int tmp=L[r-l+1];
		return Max(S[tmp][l],S[tmp][r-(1<<tmp)+1]);
	}
	inline void Build(int*A,int n){
		L[0]=L[1]=0;
		for(re int i=2;i<=n;++i)L[i]=L[i>>1]+1;
		for(re int i=1;i<=n;++i)
			if(A[i]>=0)S[0][i]=(node){A[i],-inf,A[i],inf};
			else S[0][i]=(node){-inf,A[i],inf,A[i]};
		for(re int i=1;i<=20;++i)
			for(re int j=1;j+(1<<i)-1<=n;++j)
				S[i][j]=Max(S[i-1][j],S[i-1][j+(1<<i-1)]);
	}
}S1,S2;
int n,m,q,a[100002],b[100002];
int main(){
	freopen("game.in","r",stdin);
	freopen("game.out","w",stdout);
	n=read(),m=read(),q=read();
	for(re int i=1;i<=n;++i)a[i]=read();
	for(re int i=1;i<=m;++i)b[i]=read();
	S1.Build(a,n),S2.Build(b,m);
	while(q--){
		re int l1=read(),r1=read(),l2=read(),r2=read();
		node ans1=S1.ask(l1,r1),ans2=S2.ask(l2,r2);
		long long ans=-1e18;
		for(re int i=0;i<4;++i)if(ans1.a[i]>-inf&&ans1.a[i]<inf){
			long long tmp=1e18;
			for(re int j=0;j<4;++j)
				if(ans2.a[j]>-inf&&ans2.a[j]<inf)
					tmp=min(tmp,1ll*ans1.a[i]*ans2.a[j]);
			ans=max(ans,tmp);
		}
		printf("%lld\n",ans);
	}	
}
/*
#include<bits/stdc++.h>
#define re register
#define ll long long
using namespace std;
mt19937 rng(time(0));
int n,m,k,p[10002],o1,o2;
map<int,int>V[10002];
int inf=1e9;
inline void Gen(){
	k=n-rand()%3,m=n-rand()%3,n-=rand()%3;
	printf("%d %d %d\n",n,m,k);
	if(o1){
		for(re int i=1;i<=n;++i)printf("%d ",rng()%inf+1);
		puts("");
	}
	else{
		for(re int i=1;i<=n/5;++i)printf("%d ",rng()%inf+1);
		for(re int i=n/5+1;i<=2*n/5;++i)printf("%d ",-(rng()%inf+1));
		for(re int i=2*n/5+1;i<=3*n/5;++i)printf("%d ",(rng()%10==0?0:rng()%inf+1));
		for(re int i=3*n/5+1;i<=4*n/5;++i)printf("%d ",(rng()%10==0?0:-(rng()%inf+1)));
		for(re int i=4*n/5+1;i<=n;++i)printf("%d ",rng()%(inf+inf)-inf);
	}
	if(o1){
		for(re int i=1;i<=m;++i)printf("%d ",rng()%inf+1);
		puts("");
	}
	else{
		for(re int i=1;i<=m/5;++i)printf("%d ",rng()%inf+1);
		for(re int i=m/5+1;i<=2*m/5;++i)printf("%d ",-(rng()%inf+1));
		for(re int i=2*m/5+1;i<=3*m/5;++i)printf("%d ",(rng()%10==0?0:rng()%inf+1));
		for(re int i=3*m/5+1;i<=4*m/5;++i)printf("%d ",(rng()%10==0?0:-(rng()%inf+1)));
		for(re int i=4*m/5+1;i<=m;++i)printf("%d ",rng()%(inf+inf)-inf);
	}
	while(k--){
		int l1=rng()%n+1,r1=rng()%n+1,l2=rng()%m+1,r2=rng()%m+1;
		if(l1>r1)swap(l1,r1);
		if(l2>r2)swap(l2,r2);
		printf("%d %d %d %d\n",l1,r1,l2,r2);
	}
}
int main(){
	for(int id=1;id<=20;++id){
		string tmp="game"+to_string(id)+".in";
		freopen(tmp.c_str(),"w",stdout);
		if(id<=5)n=200;
		else if(id<=12)n=1000;
		else n=100000;o1=o2=0;
		if(id==1||id==2||id==6||id==7||id==8||id==13||id==14||id==15)o1=1;
		if(id==1||id==3||id==6||id==9||id==10||id==13||id==16||id==17)o2=1;
		Gen();
	}
}
*/

//mo bai chuan qi te ji da shi luo si yuan, jin ri zai IOI pai hang bang cheng nin wei da xia zun gui de da ming, yi gu jing pei zhi you sheng ran er, nin zai IOI wei guo zheng guang, yang wo hua wei ming, xiang nin xian shang zui zhen zhi de mo bai
//sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz 
//lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%
//SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077
//SiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWow
//huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le
//zai mo yi ci luo si yuan orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz
//mo bai chuan qi te ji da shi luo si yuan, jin ri zai IOI pai hang bang cheng nin wei da xia zun gui de da ming, yi gu jing pei zhi you sheng ran er, nin zai IOI wei guo zheng guang, yang wo hua wei ming, xiang nin xian shang zui zhen zhi de mo bai
//I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!
//feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!
//luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!
//dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!
//dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!
#include<bits/stdc++.h>
#define re register
#define ll long long
using namespace std;
inline ll read(){
	re ll t=0;re char v=getchar();
	while(v<'0')v=getchar();
	while(v>='0')t=(t<<3)+(t<<1)+v-48,v=getchar();
	return t;
}
int t,n,m,k,head[2502],cnt,Q[2502],hd,tl,dis[2502],A[2502][4];
ll a[2502],ans;
char v[2502][2502];
struct edge{
	int to,next;
}e[20002];
inline void add(re int x,re int y){e[++cnt]=(edge){y,head[x]},head[x]=cnt;}
int main(){
	freopen("holiday.in","r",stdin);
	freopen("holiday.out","w",stdout);
	n=read(),m=read(),k=read();
	for(re int i=2;i<=n;++i)a[i]=read();
	for(re int i=1,x,y;i<=m;++i)x=read(),y=read(),add(x,y),add(y,x);
	for(re int i=1;i<=n;++i){
		for(re int j=1;j<=n;++j)dis[j]=-1;
		Q[hd=tl=1]=i,dis[i]=0;
		while(hd<=tl){
			re int x=Q[hd++];
			for(re int j=head[x];j;j=e[j].next)if(dis[e[j].to]==-1)dis[e[j].to]=dis[x]+1,Q[++tl]=e[j].to;
		}
		for(re int j=1;j<=n;++j)v[i][j]=dis[j]!=-1&&dis[j]<=k+1;
	}
	for(re int i=2;i<=n;++i){
		for(re int j=2;j<=n;++j)
			if(j^i&&v[i][j]&&v[1][j]){
				re int cur=j;
				for(re int k=1;k<=3;++k)if(a[cur]>a[A[i][k]])swap(cur,A[i][k]);
			}
	}
	for(re int i=2;i<=n;++i)
		for(re int j=i+1;j<=n;++j)
			if(v[i][j])
				for(re int o1=1;o1<=3;++o1)
					for(re int o2=1;o2<=3;++o2)
						if(A[i][o1]&&A[j][o2]&&A[i][o1]!=j&&A[j][o2]!=i&&A[i][o1]!=A[j][o2])
							ans=max(ans,a[i]+a[j]+a[A[i][o1]]+a[A[j][o2]]);
	printf("%lld",ans);
}
/*
#include<bits/stdc++.h>
#define re register
#define ll long long
using namespace std;
mt19937 rng(time(0));
int n,m,k,p[10002];
map<int,int>V[10002];
ll lmt;
inline void Gen(){
	printf("%d %d %d\n",n,m,k);
	for(re int i=1;i<=n;++i)p[i]=i;
	random_shuffle(p+2,p+n+1);
	for(re int i=2;i<=n;++i)printf("%lld ",(((1ull<<32)*rng())|rng())%lmt+1);puts("");
	n-=rand()%5;
	for(re int i=1;i<=n;++i)V[i].clear();
	for(re int i=1;i<n;++i)printf("%d %d\n",p[i],p[i+1]),V[p[i]][p[i+1]]=V[p[i+1]][p[i]]=1;
	for(re int i=n;i<=max(m-20,m/50*49);++i){
		int x=rng()%(n-1)+1,y=x+rng()%min(5,(n-x))+1;
		while(V[p[x]].count(p[y]))x=rng()%(n-1)+1,y=x+rng()%min(5,(n-x))+1;
		printf("%d %d\n",p[x],p[y]);
		V[p[x]][p[y]]=V[p[y]][p[x]]=1;
	}
	for(re int i=max(m-20,m/50*49)+1;i<=m;++i){
		int x=rng()%n+1,y=rng()%n+1;
		while(V[x].count(y))x=rng()%n+1,y=rng()%n+1;
		printf("%d %d\n",x,y);
		V[x][y]=V[y][x]=1;
	}
}
int main(){
	for(int id=1;id<=20;++id){
		string tmp="holiday"+to_string(id)+".in";
		freopen(tmp.c_str(),"w",stdout);
		lmt=1e18;
		if((id%5)%2==0)lmt=1e5;
		if(id<=3)n=10,m=20,k=0;
		else if(id<=5)n=10,m=20,k=5-(rng()&1);
		else if(id<=6)n=20,m=50,k=rng()%5;
		else if(id<=8)n=20,m=50,k=rng()%100;
		else if(id<=11)n=300,m=1000,k=0;
		else if(id<=14)n=300,m=1000,k=rng()%100;
		else if(id<=17)n=2500,m=10000,k=0;
		else n=2500,m=10000,k=rng()%100;
		Gen();
	}
}
*/

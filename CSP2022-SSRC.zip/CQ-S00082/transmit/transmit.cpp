//mo bai chuan qi te ji da shi luo si yuan, jin ri zai IOI pai hang bang cheng nin wei da xia zun gui de da ming, yi gu jing pei zhi you sheng ran er, nin zai IOI wei guo zheng guang, yang wo hua wei ming, xiang nin xian shang zui zhen zhi de mo bai
//sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz sto lsy orz 
//lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%lsytql%%%
//SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077SiyuanLuoWillWinIOI2023&&IOI2077
//SiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWowSiyuanLuoSoBeautifulWowWowWow
//huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le huan ying guang lin infoj wang zhi wo wang le
//zai mo yi ci luo si yuan orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz orz
//mo bai chuan qi te ji da shi luo si yuan, jin ri zai IOI pai hang bang cheng nin wei da xia zun gui de da ming, yi gu jing pei zhi you sheng ran er, nin zai IOI wei guo zheng guang, yang wo hua wei ming, xiang nin xian shang zui zhen zhi de mo bai
//I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!I love feecle6418 forever!!!!
//feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!feecle6418 AK IOI!!!
//luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!luo si yuan bao you wo bu gua fen!!!
//dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!dottle bot!!!!
//dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!dottleKFCCrazyThursdayvme50!!!!
#include<bits/stdc++.h>
#define re register
#define ll long long
using namespace std;
inline int read(){
	re int t=0;re char v=getchar();
	while(v<'0')v=getchar();
	while(v>='0')t=(t<<3)+(t<<1)+v-48,v=getchar();
	return t;
}
struct Mat{
	ll a[3][3];
	inline void clr(){memset(a,0x3f,sizeof(a));}
}S[200002],M1[200002],M2[200002];
struct edge{int to,next;}e[400002];
struct Query{int x,y,id;};
int n,q,K,v[200002],head[200002],cnt,siz[200002],Mn,Z,pos,bl[200002],MNV[200002];
ll ans[200002];
char vis[200002];
inline void add(re int x,re int y){MNV[x]=min(MNV[x],v[y]);e[++cnt]=(edge){y,head[x]},head[x]=cnt;}
inline Mat mul(Mat A,Mat B){
	Mat C;C.clr();
	for(re int i=0;i<K;++i)for(re int j=0;j<K;++j)for(re int k=0;k<K;++k)C.a[i][k]=min(C.a[i][k],A.a[i][j]+B.a[j][k]);
	return C;
}
inline void dfs(re int x,re int y){
	siz[x]=1;re int mx=0;
	for(re int i=head[x];i;i=e[i].next)if(e[i].to^y&&!vis[e[i].to])dfs(e[i].to,x),siz[x]+=siz[e[i].to],mx=max(mx,siz[e[i].to]);
	mx=max(mx,Z-siz[x]);
	if(mx<Mn)Mn=mx,pos=x;
}
inline void dfs1(re int x,re int y,re int z){
	bl[x]=z,M1[x]=mul(S[x],M1[y]),M2[x]=mul(M2[y],S[x]);
	for(re int i=head[x];i;i=e[i].next)
		if(e[i].to^y&&!vis[e[i].to])
			dfs1(e[i].to,x,z);
}
vector<Query>Tmp[200002];
inline void solve(re int x,re int y,vector<Query>Q){
	Tmp[x].clear();
	if(y==1)return;
	Mn=1e9,Z=y,dfs(x,x),x=pos,dfs(x,x),M1[x]=S[x],M2[x].clr(),bl[x]=x,vis[x]=1;
	for(re int i=0;i<K;++i)M2[x].a[i][i]=0;
	for(re int i=head[x];i;i=e[i].next)
		if(!vis[e[i].to])
			dfs1(e[i].to,x,e[i].to);
	for(auto z:Q)
		if(bl[z.x]!=bl[z.y])ans[z.id]=mul(M1[z.x],M2[z.y]).a[K-1][0];
		else Tmp[bl[z.x]].push_back(z);
	for(re int i=head[x];i;i=e[i].next)if(!vis[e[i].to])solve(e[i].to,siz[e[i].to],Tmp[e[i].to]);
}
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	n=read(),q=read(),K=read();
	for(re int i=1;i<=n;++i)v[i]=read(),MNV[i]=1e9;
	for(re int i=1,x,y;i<n;++i)x=read(),y=read(),add(x,y),add(y,x);
	for(re int i=1;i<=n;++i){
		S[i].clr();
		for(re int j=0;j+1<K;++j)S[i].a[j][j+1]=0;
		for(re int j=0;j<K;++j)S[i].a[j][0]=v[i];
		if(K==3)S[i].a[1][1]=MNV[i];
	}
	vector<Query>tmp;
	for(re int i=1,x,y;i<=q;++i)x=read(),y=read(),tmp.push_back((Query){x,y,i});
	solve(1,n,tmp);
	for(re int i=1;i<=q;++i)printf("%lld\n",ans[i]);
}
/*
#include<bits/stdc++.h>
#define re register
#define ll long long
using namespace std;
mt19937 rng(time(0));
int n,m,k,p[500002],o1,o2,lmt,inf=1e9;
inline void Gen(){
	m=n-rand()%3,n-=rand()%3;
	printf("%d %d %d\n",n,m,k);
	for(re int i=1;i<=n;++i)p[i]=i,printf("%d ",rng()%inf+1);puts("");
	if(lmt==4)random_shuffle(p+1,p+n+1);
	for(re int i=2;i<=n;++i){
		int x=i-1-rng()%min(lmt,(i-1));
		printf("%d %d\n",p[x],p[i]);
	}
	while(m--){
		int x=rng()%n+1,y=rng()%n+1;
		while(x==y)x=rng()%n+1,y=rng()%n+1;
		printf("%d %d\n",x,y);
	}
}
int main(){
	for(int id=1;id<=25;++id){
		string tmp="transmit"+to_string(id)+".in";
		freopen(tmp.c_str(),"w",stdout);
		lmt=4;
		if(id<=2)n=10;
		else if(id<=5)n=200;
		else if(id<=11)n=2000;
		else if(id<=13)n=200000;
		else if(id<=14)n=50000;
		else if(id<=16)n=100000;
		else if(id<=19)n=200000;
		else if(id<=20)n=50000;
		else if(id<=22)n=100000;
		else n=200000;
		if(id==6||id==7||id==12||id==13)k=1;
		else if(id==1||id==3||id==8||id==9||(id>=14&&id<=19))k=2;
		else k=3;
		if(id<=5||(id>=14&&id<=16)||(id>=20&&id<=22))lmt=1e9;
		Gen();
	}
}
*/

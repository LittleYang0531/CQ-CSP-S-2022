#include<bits/stdc++.h>
using namespace std;
int n,m,q;
int main() 
{
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
    cin>>n>>m>>q;
    for(int i=1;i<=q;i++)
        cout<<1<<endl;
	cout<<endl;
	return 0;
}

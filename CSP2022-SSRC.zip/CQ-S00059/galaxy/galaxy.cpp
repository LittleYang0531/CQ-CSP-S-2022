#include<bits/stdc++.h>
#define ll long long
#define maxn 100005
using namespace std;
int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	cout<<"NO";
	return 0;
}

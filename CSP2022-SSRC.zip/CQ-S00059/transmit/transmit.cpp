#include<bits/stdc++.h>
#define ll long long
#define maxn 100005
using namespace std;

int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	printf("3");
	return 0;
}

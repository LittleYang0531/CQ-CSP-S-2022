#include<bits/stdc++.h>
using namespace std;
long long n,m,q,k;
int main(){
freopen("galaxy.in","r",stdin);
freopen("galaxy.out","w",stdout);
cin>>n>>m;
for(int i=1;i<=m;i++){
	int u,u1;
	cin>>u>>u1;
}
cin>>q;
for(int i=1;i<=q;i++){
	int x,y,z;
	cin>>x;
	if(x==1||x==3) cin>>y>>z;
	else cin>>y;
}
for(int i=1;i<=q;i++){
	cout<<"YES";
}
return 0;
}


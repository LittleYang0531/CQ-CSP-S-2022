#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("transmit.in","r",stdin);
	freopen("transmit.out","w",stdout);
	printf("666");
	return 0;
}


#include<bits/stdc++.h>
using namespace std;


int main(){
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	ios::sync_with_stdio(false);
	cout<<0;
	return 0;
}

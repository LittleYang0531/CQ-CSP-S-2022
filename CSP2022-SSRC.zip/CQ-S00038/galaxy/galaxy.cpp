#include<bits/stdc++.h>
using namespace std;
int main() {
	freopen("galaxy.in","r",stdin);
	freopen("galaxy.out","w",stdout);
	int n,m;
	cin>>n>>m;
	while(m--) {
		int u,v;
		cin>>u>>v;
	}
	int q;
	cin>>q;
	while(q--) {
		int x;
		cin>>x;
		if(x==1&&x==3) {
			int a,b;
			cin>>a>>b;
			cout<<"NO\n";
		} else {
			int a;
			cin>>a;
			cout<<"NO\n";
		}
	}
	return 0;
}
